# 1. Import Flask


# 2. Create an app


# 3. Define index route


# 4. Define the about route


# 5. Define the contact route


# 6. Define main behavior
