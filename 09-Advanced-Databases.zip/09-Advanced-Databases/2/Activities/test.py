from flask import Flask, jsonify

app = Flask(__name__)

name = "Khaled Karman"
languages = ["Python", "Javascript"]
full_info = {
    "name": name,
    "languages": languages
}

justice_league_members = [
    {"superhero": "Aquaman", "real_name": "Arthur Curry"},
    {"superhero": "Batman", "real_name": "Bruce Wayne"},
    {"superhero": "Cyborg", "real_name": "Victor Stone"},
    {"superhero": "Flash", "real_name": "Barry Allen"},
    {"superhero": "Green Lantern", "real_name": "Hal Jordan"},
    {"superhero": "Superman", "real_name": "Clark Kent/Kal-El"},
    {"superhero": "Wonder Woman", "real_name": "Princess Diana"}
]

@app.route("/")
def home():
    print("Hello")
    return """
    <b>Welcom</b> to my <i>own</i> PAGE
    <br> <a href="/info">My Info</a>
    <br> <a href="/name">My Name</a>
    <br> <a href="/fullinfo">My Full Info</a>
    <br> <a href="/api/v1.0/justice-league">Justice-League Members</a>
    <br> <a href="/api/v1.0/superhero/Aquaman">Justice-League (Aquaman)</a>
    """

@app.route("/info")
def show_inf():
    return str(languages)

@app.route("/name")
def show_name():
    return jsonify(name)

@app.route("/fullinfo")
def show_fullinfo():
    return jsonify(full_info)

@app.route("/api/v1.0/justice-league")
def show_justiceleague():
    return jsonify(justice_league_members)


@app.route("/api/v1.0/superhero/<superhero>")
def show_justiceleague_superhero(superhero):
    info = {}
    for x in justice_league_members:
        if x["superhero"]==superhero:
            info = x
    return jsonify(info)

@app.route("/api/v1.0/real_name/<real_name>")
def show_justiceleague_real_name(real_name):
    info = {}
    for x in justice_league_members:
        if x["real_name"]==real_name:
            info = x
    return jsonify(info)


if __name__=="__main__":
    app.run(debug=True)
